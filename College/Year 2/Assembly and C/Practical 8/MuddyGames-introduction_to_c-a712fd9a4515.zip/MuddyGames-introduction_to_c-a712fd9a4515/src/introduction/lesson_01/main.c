#include "stdio.h" // standard IO header file

// Mainline
int main()
{
    printf("Hello Assembly and C\n"); // Call to printf function
    return 0;
}